"""
PSA Academy — asosiy server.

Bitta process ichida ikkita narsa ishlaydi:
  1) FastAPI — Mini App uchun REST API va statik fayllarni (frontend) beradi.
  2) Aiogram bot — /start bosilganda "Ilovani ochish" tugmasini yuboradi.

Ishga tushirish:  uvicorn main:app --host 0.0.0.0 --port 8000
(BOT_TOKEN va WEBAPP_URL muhit o'zgaruvchilari orqali beriladi — README'ga qarang)
"""
import os
import hmac
import hashlib
import json
import time
import asyncio
import logging
from urllib.parse import parse_qsl
from contextlib import asynccontextmanager

from fastapi import FastAPI, Header, HTTPException, Depends
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from aiogram import Bot, Dispatcher, types
from aiogram.filters import CommandStart
from aiogram.types import WebAppInfo, InlineKeyboardMarkup, InlineKeyboardButton

from database import (
    init_db, get_or_create_user, get_user, add_xp,
    complete_lesson, get_progress, get_leaderboard,
    save_quiz_result, get_quiz_results,
)
from content import MODULES, get_module, get_lesson

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("psa-academy")

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
WEBAPP_URL = os.environ.get("WEBAPP_URL", "")  # masalan: https://sizning-app.onrender.com
ADMIN_IDS = {int(x) for x in os.environ.get("ADMIN_IDS", "").split(",") if x.strip().isdigit()}

DEV_MODE = not BOT_TOKEN  # token bo'lmasa, mahalliy sinov rejimi (himoyasiz)


# ----------------------- Telegram initData tekshirish -----------------------

def validate_init_data(init_data: str) -> dict:
    """Telegram Mini App yuborgan initData haqiqiyligini HMAC orqali tekshiradi."""
    if DEV_MODE:
        return {"id": 999999999, "first_name": "Sinov", "username": "test_user"}

    if not init_data:
        raise HTTPException(401, "initData yo'q")

    parsed = dict(parse_qsl(init_data, strict_parsing=False))
    received_hash = parsed.pop("hash", None)
    if not received_hash:
        raise HTTPException(401, "hash topilmadi")

    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(parsed.items()))
    secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    computed_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

    if computed_hash != received_hash:
        raise HTTPException(401, "Noto'g'ri imzo (hash mos kelmadi)")

    auth_date = int(parsed.get("auth_date", 0))
    if time.time() - auth_date > 86400:
        raise HTTPException(401, "initData eskirgan")

    return json.loads(parsed.get("user", "{}"))


async def get_current_user(x_init_data: str = Header(default="")):
    tg_user = validate_init_data(x_init_data)
    if not tg_user or "id" not in tg_user:
        raise HTTPException(401, "Foydalanuvchi aniqlanmadi")
    return tg_user


# ------------------------------- Telegram bot --------------------------------

bot: Bot | None = None
dp = Dispatcher()


@dp.message(CommandStart())
async def cmd_start(message: types.Message):
    if WEBAPP_URL:
        kb = InlineKeyboardMarkup(inline_keyboards := [[
            InlineKeyboardButton(
                text="🚀 Akademiyani ochish",
                web_app=WebAppInfo(url=WEBAPP_URL),
            )
        ]])
        await message.answer(
            f"Assalomu alaykum, {message.from_user.first_name}!\n\n"
            "PSA — Pro Sales Academy'ga xush kelibsiz.\n"
            "Darslar, testlar va reyting jadvali — barchasi pastdagi tugma orqali.",
            reply_markup=kb,
        )
    else:
        await message.answer(
            "Bot ishlamoqda, lekin WEBAPP_URL sozlanmagan. "
            "Iltimos, muhit o'zgaruvchisiga ilova manzilini kiriting."
        )


async def run_bot():
    global bot
    if not BOT_TOKEN:
        log.warning("BOT_TOKEN berilmagan — bot ishga tushmaydi (faqat API sinov rejimida ishlaydi).")
        return
    bot = Bot(token=BOT_TOKEN)
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


# -------------------------------- FastAPI app --------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    task = asyncio.create_task(run_bot())
    yield
    task.cancel()


app = FastAPI(title="PSA Academy API", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)


def level_from_xp(xp: int) -> int:
    return xp // 100 + 1


def serialize_profile(row: dict) -> dict:
    xp = row["xp"]
    level = level_from_xp(xp)
    next_level_xp = level * 100
    return {
        "telegram_id": row["telegram_id"],
        "first_name": row["first_name"],
        "username": row["username"],
        "xp": xp,
        "level": level,
        "xp_to_next_level": next_level_xp - xp,
    }


# ---- Auth / profile ----

@app.post("/api/auth")
async def auth(tg_user: dict = Depends(get_current_user)):
    get_or_create_user(tg_user["id"], tg_user.get("first_name", ""), tg_user.get("username", ""))
    return serialize_profile(get_user(tg_user["id"]))


@app.get("/api/profile")
async def profile(tg_user: dict = Depends(get_current_user)):
    row = get_user(tg_user["id"])
    if not row:
        raise HTTPException(404, "Foydalanuvchi topilmadi")
    progress = get_progress(tg_user["id"])
    quiz_results = get_quiz_results(tg_user["id"])
    total_lessons = sum(len(m["lessons"]) for m in MODULES)
    return {
        **serialize_profile(row),
        "completed_lessons": len(progress),
        "total_lessons": total_lessons,
        "quiz_results": quiz_results,
    }


# ---- Modules / lessons ----

@app.get("/api/modules")
async def list_modules(tg_user: dict = Depends(get_current_user)):
    progress = get_progress(tg_user["id"])
    quiz_results = get_quiz_results(tg_user["id"])
    out = []
    for m in MODULES:
        done = sum(1 for l in m["lessons"] if l["id"] in progress)
        out.append({
            "id": m["id"],
            "title": m["title"],
            "icon": m["icon"],
            "description": m["description"],
            "lesson_count": len(m["lessons"]),
            "completed_count": done,
            "quiz_done": m["id"] in quiz_results,
            "quiz_score": quiz_results.get(m["id"]),
        })
    return out


@app.get("/api/modules/{module_id}")
async def module_detail(module_id: str, tg_user: dict = Depends(get_current_user)):
    m = get_module(module_id)
    if not m:
        raise HTTPException(404, "Modul topilmadi")
    progress = get_progress(tg_user["id"])
    lessons = [
        {"id": l["id"], "title": l["title"], "xp": l["xp"], "completed": l["id"] in progress}
        for l in m["lessons"]
    ]
    return {
        "id": m["id"], "title": m["title"], "icon": m["icon"],
        "description": m["description"], "lessons": lessons,
        "has_quiz": bool(m.get("quiz")),
    }


@app.get("/api/lessons/{lesson_id}")
async def lesson_detail(lesson_id: str, tg_user: dict = Depends(get_current_user)):
    lesson, module = get_lesson(lesson_id)
    if not lesson:
        raise HTTPException(404, "Dars topilmadi")
    progress = get_progress(tg_user["id"])
    idx = [l["id"] for l in module["lessons"]].index(lesson_id)
    next_id = module["lessons"][idx + 1]["id"] if idx + 1 < len(module["lessons"]) else None
    return {
        "id": lesson["id"], "title": lesson["title"], "content": lesson["content"],
        "xp": lesson["xp"], "completed": lesson_id in progress,
        "module_id": module["id"], "module_title": module["title"],
        "next_lesson_id": next_id,
    }


@app.post("/api/lessons/{lesson_id}/complete")
async def mark_lesson_complete(lesson_id: str, tg_user: dict = Depends(get_current_user)):
    lesson, module = get_lesson(lesson_id)
    if not lesson:
        raise HTTPException(404, "Dars topilmadi")
    is_new = complete_lesson(tg_user["id"], lesson_id)
    xp_awarded = lesson["xp"] if is_new else 0
    new_xp = add_xp(tg_user["id"], xp_awarded) if is_new else get_user(tg_user["id"])["xp"]
    return {"completed": True, "xp_awarded": xp_awarded, "total_xp": new_xp}


# ---- Quiz ----

class QuizSubmission(BaseModel):
    answers: list[int]


@app.get("/api/quizzes/{module_id}")
async def get_quiz(module_id: str, tg_user: dict = Depends(get_current_user)):
    m = get_module(module_id)
    if not m or not m.get("quiz"):
        raise HTTPException(404, "Test topilmadi")
    questions = [{"question": q["question"], "options": q["options"]} for q in m["quiz"]]
    return {"module_id": module_id, "questions": questions}


@app.post("/api/quizzes/{module_id}/submit")
async def submit_quiz(module_id: str, submission: QuizSubmission, tg_user: dict = Depends(get_current_user)):
    m = get_module(module_id)
    if not m or not m.get("quiz"):
        raise HTTPException(404, "Test topilmadi")
    quiz = m["quiz"]
    if len(submission.answers) != len(quiz):
        raise HTTPException(400, "Javoblar soni mos kelmadi")
    score = sum(1 for i, q in enumerate(quiz) if submission.answers[i] == q["correct"])
    save_quiz_result(tg_user["id"], module_id, score, len(quiz))
    xp_awarded = score * 5
    new_xp = add_xp(tg_user["id"], xp_awarded)
    return {"score": score, "total": len(quiz), "xp_awarded": xp_awarded, "total_xp": new_xp}


# ---- Leaderboard ----

@app.get("/api/leaderboard")
async def leaderboard(tg_user: dict = Depends(get_current_user)):
    rows = get_leaderboard(50)
    return [
        {
            "rank": i + 1,
            "telegram_id": r["telegram_id"],
            "first_name": r["first_name"],
            "username": r["username"],
            "xp": r["xp"],
            "level": level_from_xp(r["xp"]),
            "is_me": r["telegram_id"] == tg_user["id"],
        }
        for i, r in enumerate(rows)
    ]


# ---- Statik frontend fayllarni berish (eng oxirida ro'yxatdan o'tkaziladi) ----
FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.isdir(FRONTEND_DIR):
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
