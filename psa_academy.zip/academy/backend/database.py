"""
PSA Academy — ma'lumotlar bazasi qatlami.
SQLite ishlatiladi (qo'shimcha server talab qilmaydi, fayl sifatida saqlanadi).
"""
import sqlite3
import time
from contextlib import contextmanager

DB_PATH = "academy.db"


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                telegram_id INTEGER PRIMARY KEY,
                first_name TEXT,
                username TEXT,
                xp INTEGER DEFAULT 0,
                created_at INTEGER
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS lesson_progress (
                telegram_id INTEGER,
                lesson_id TEXT,
                completed_at INTEGER,
                PRIMARY KEY (telegram_id, lesson_id)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS quiz_results (
                telegram_id INTEGER,
                module_id TEXT,
                score INTEGER,
                total INTEGER,
                completed_at INTEGER,
                PRIMARY KEY (telegram_id, module_id)
            )
        """)


def get_or_create_user(telegram_id: int, first_name: str, username: str):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO users (telegram_id, first_name, username, xp, created_at) VALUES (?,?,?,0,?)",
                (telegram_id, first_name, username, int(time.time())),
            )
        else:
            conn.execute(
                "UPDATE users SET first_name=?, username=? WHERE telegram_id=?",
                (first_name, username, telegram_id),
            )


def get_user(telegram_id: int):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
        return dict(row) if row else None


def add_xp(telegram_id: int, amount: int):
    with get_conn() as conn:
        conn.execute("UPDATE users SET xp = xp + ? WHERE telegram_id=?", (amount, telegram_id))
        row = conn.execute("SELECT xp FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
        return row["xp"] if row else 0


def complete_lesson(telegram_id: int, lesson_id: str):
    with get_conn() as conn:
        already = conn.execute(
            "SELECT 1 FROM lesson_progress WHERE telegram_id=? AND lesson_id=?",
            (telegram_id, lesson_id),
        ).fetchone()
        if already:
            return False
        conn.execute(
            "INSERT INTO lesson_progress (telegram_id, lesson_id, completed_at) VALUES (?,?,?)",
            (telegram_id, lesson_id, int(time.time())),
        )
        return True


def get_progress(telegram_id: int):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT lesson_id FROM lesson_progress WHERE telegram_id=?", (telegram_id,)
        ).fetchall()
        return {r["lesson_id"] for r in rows}


def save_quiz_result(telegram_id: int, module_id: str, score: int, total: int):
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO quiz_results (telegram_id, module_id, score, total, completed_at)
               VALUES (?,?,?,?,?)
               ON CONFLICT(telegram_id, module_id)
               DO UPDATE SET score=excluded.score, total=excluded.total, completed_at=excluded.completed_at
               WHERE excluded.score > quiz_results.score""",
            (telegram_id, module_id, score, total, int(time.time())),
        )


def get_quiz_results(telegram_id: int):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT module_id, score, total FROM quiz_results WHERE telegram_id=?", (telegram_id,)
        ).fetchall()
        return {r["module_id"]: {"score": r["score"], "total": r["total"]} for r in rows}


def get_leaderboard(limit: int = 50):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT telegram_id, first_name, username, xp FROM users ORDER BY xp DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]
