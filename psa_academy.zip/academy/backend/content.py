"""
PSA Academy — kurs kontenti.

BU FAYLNI TAHRIRLASH ORQALI o'z darslaringizni, savollaringizni qo'sha olasiz.
Har bir modul: id, title, icon, tavsif va lessons ro'yxatidan iborat.
Har bir dars (lesson): id (NOYOB bo'lishi shart), title, content (matn), xp (mukofot).
Har bir modulning quiz'i (test): questions ro'yxati, har savolda variantlar va to'g'ri javob indeksi.

Yangi dars qo'shish uchun shunchaki "lessons" ro'yxatiga yangi dict qo'shing.
Yangi modul qo'shish uchun MODULES ro'yxatiga yangi dict qo'shing.
"""

MODULES = [
    {
        "id": "sotuv",
        "title": "Sotuv san'ati",
        "icon": "🎯",
        "description": "Sotuv texnikalari, e'tirozlar bilan ishlash, muzokara asoslari",
        "lessons": [
            {
                "id": "sotuv_1",
                "title": "1-dars: Sotuvning oltin qoidasi",
                "xp": 10,
                "content": (
                    "Sotuv — mahsulotni emas, natijani sotish demakdir.\n\n"
                    "Mijoz mahsulotning o'zini emas, u beradigan yechimni sotib oladi. "
                    "Har bir taqdimotdan oldin o'zingizga savol bering: "
                    "\"Bu mahsulot mijozning qaysi muammosini yechadi?\"\n\n"
                    "Amaliyot: Bugun bitta mijoz bilan suhbatda, mahsulot xususiyati o'rniga "
                    "u keltiradigan foydani gapirib ko'ring."
                ),
            },
            {
                "id": "sotuv_2",
                "title": "2-dars: E'tirozlar bilan ishlash (AQFT usuli)",
                "xp": 10,
                "content": (
                    "E'tirozga to'g'ridan-to'g'ri qarshi chiqmang — AQFT usulidan foydalaning:\n\n"
                    "A — Anglash (mijoz fikrini tasdiqlang)\n"
                    "Q — Qayta so'rash (aniqlashtiruvchi savol bering)\n"
                    "F — Fikr bildirish (yechimni taklif qiling)\n"
                    "T — Tasdiqlash (kelishuvga erishing)\n\n"
                    "Amaliyot: Eng ko'p uchraydigan e'tirozingizni yozing va shu 4 qadamda javob tayyorlang."
                ),
            },
            {
                "id": "sotuv_3",
                "title": "3-dars: Bitimni yopish signallari",
                "xp": 10,
                "content": (
                    "Mijoz bitimga tayyor bo'lganda bergan signallarni tanish muhim: "
                    "narx haqida batafsil so'rash, yetkazib berish muddatini so'rash, "
                    "\"agar men olsam...\" degan gaplar.\n\n"
                    "Bu signallarni ko'rgach, darhol yopish savolini bering: "
                    "\"Qaysi variant sizga qulayroq — A yoki B?\"\n\n"
                    "Amaliyot: Keyingi suhbatda ushbu signallardan birini payqashga harakat qiling."
                ),
            },
        ],
        "quiz": [
            {
                "question": "Mijoz aslida nimani sotib oladi?",
                "options": ["Mahsulotning o'zini", "Yechim/natijani", "Narxni", "Brendni"],
                "correct": 1,
            },
            {
                "question": "AQFT usulida \"Q\" nimani anglatadi?",
                "options": ["Qaror qilish", "Qayta so'rash", "Qiymat berish", "Qat'iylik"],
                "correct": 1,
            },
        ],
    },
    {
        "id": "tizim",
        "title": "Biznesni tizimlashtirish",
        "icon": "⚙️",
        "description": "Jarayonlarni SOP'ga aylantirish, avtomatlashtirish",
        "lessons": [
            {
                "id": "tizim_1",
                "title": "1-dars: Nega tizim sizsiz ishlashi kerak",
                "xp": 10,
                "content": (
                    "Agar biznesingiz faqat siz ishtirok etganda ishlasa — bu biznes emas, ish o'rni.\n\n"
                    "Tizim — takrorlanadigan jarayonni yozma qoidaga aylantirish. "
                    "Har bir doimiy vazifa uchun oddiy savol bering: "
                    "\"Buni boshqa birov men aytmasdan qila oladimi?\"\n\n"
                    "Amaliyot: Bugun bitta takrorlanadigan vazifangizni qadam-baqadam yozib chiqing (SOP)."
                ),
            },
            {
                "id": "tizim_2",
                "title": "2-dars: Checklist kuchi",
                "xp": 10,
                "content": (
                    "Murakkab jarayonni oddiy checklistga aylantiring — xatolar keskin kamayadi.\n\n"
                    "Yaxshi checklist: aniq, qisqa buyruq shaklida, tartib bilan yozilgan bo'ladi.\n\n"
                    "Amaliyot: Jamoangizdagi eng ko'p xato bo'ladigan jarayon uchun checklist tuzing."
                ),
            },
        ],
        "quiz": [
            {
                "question": "Tizimlashtirishning asosiy maqsadi nima?",
                "options": [
                    "Xodimlarni kamaytirish",
                    "Jarayonni odamga bog'liqsiz qilish",
                    "Narxni oshirish",
                    "Reklama qilish",
                ],
                "correct": 1,
            },
        ],
    },
    {
        "id": "boshqaruv",
        "title": "Boshqaruv va jamoa",
        "icon": "👥",
        "description": "Jamoa yig'ish, motivatsiya, KPI, delegatsiya",
        "lessons": [
            {
                "id": "boshqaruv_1",
                "title": "1-dars: Delegatsiya — vazifani emas, natijani bering",
                "xp": 10,
                "content": (
                    "Ko'p rahbarlar vazifani \"qanday qilish\" bilan birga beradi — bu xodimni cheklaydi.\n\n"
                    "To'g'ri delegatsiya: aniq natija + muddat + resurs beriladi, \"qanday\"ni xodim tanlaydi.\n\n"
                    "Amaliyot: Keyingi topshiriqda faqat kutilayotgan natijani va muddatni ayting."
                ),
            },
        ],
        "quiz": [
            {
                "question": "To'g'ri delegatsiyada asosan nima beriladi?",
                "options": ["Batafsil yo'riqnoma", "Aniq natija va muddat", "Jazo tizimi", "Hech narsa"],
                "correct": 1,
            },
        ],
    },
    {
        "id": "moliya",
        "title": "Biznes moliyasi",
        "icon": "💰",
        "description": "Foyda-zarar mantiqi, narxlash, cash flow asoslari",
        "lessons": [
            {
                "id": "moliya_1",
                "title": "1-dars: Aylanma va foyda — ikkisi bir narsa emas",
                "xp": 10,
                "content": (
                    "Ko'p tadbirkorlar aylanmani foyda deb adashadi. "
                    "Aylanma — kelgan pul; foyda — xarajatlardan keyin qolgan pul.\n\n"
                    "Amaliyot: Shu oyning aylanma va sof foyda raqamlarini alohida hisoblab ko'ring."
                ),
            },
        ],
        "quiz": [
            {
                "question": "Aylanma nima?",
                "options": ["Sof foyda", "Kelgan umumiy pul", "Bank krediti", "Xarajat"],
                "correct": 1,
            },
        ],
    },
    {
        "id": "mijoz",
        "title": "Mijoz va CRM",
        "icon": "🤝",
        "description": "Mijozni ushlab qolish, follow-up tizimi",
        "lessons": [
            {
                "id": "mijoz_1",
                "title": "1-dars: Follow-up — sotuvning yashirin qismi",
                "xp": 10,
                "content": (
                    "Sotuvlarning katta qismi birinchi muloqotda emas, keyingi follow-up'larda yopiladi.\n\n"
                    "Qoida: har bir \"yo'q\" javobidan keyin qachon qayta bog'lanishni aniq belgilang.\n\n"
                    "Amaliyot: Oxirgi 5 ta \"o'ylab ko'raman\" degan mijozga follow-up jadvalini tuzing."
                ),
            },
        ],
        "quiz": [
            {
                "question": "Follow-up nima uchun muhim?",
                "options": [
                    "Mijozni bezovta qilish uchun",
                    "Ko'p sotuvlar keyingi muloqotlarda yopiladi",
                    "Reklama uchun",
                    "Hech qanday ahamiyati yo'q",
                ],
                "correct": 1,
            },
        ],
    },
    {
        "id": "keys",
        "title": "Amaliy keys'lar",
        "icon": "📊",
        "description": "Real tajriba va holatlar tahlili",
        "lessons": [
            {
                "id": "keys_1",
                "title": "1-keys: Muzlab qolgan mijozni qanday jonlantirish mumkin",
                "xp": 15,
                "content": (
                    "Holat: mijoz 2 hafta oldin qiziqish bildirgan, so'ng javob bermay qo'ygan.\n\n"
                    "Yechim yondashuvi: to'g'ridan-to'g'ri \"xarid qilasizmi\" demasdan, "
                    "yangi qiymat/ma'lumot bilan qayta murojaat qiling — bosim emas, foyda taklif qiling.\n\n"
                    "Amaliyot: O'zingizning \"muzlagan\" mijozlar ro'yxatini tuzib, shu yondashuvni sinab ko'ring."
                ),
            },
        ],
        "quiz": [
            {
                "question": "Muzlagan mijozga qayta murojaat qilishning to'g'ri yo'li?",
                "options": [
                    "Bosim o'tkazish",
                    "Yangi qiymat/foyda bilan murojaat qilish",
                    "Umuman yozmaslik",
                    "Faqat chegirma taklif qilish",
                ],
                "correct": 1,
            },
        ],
    },
]


def get_module(module_id: str):
    for m in MODULES:
        if m["id"] == module_id:
            return m
    return None


def get_lesson(lesson_id: str):
    for m in MODULES:
        for l in m["lessons"]:
            if l["id"] == lesson_id:
                return l, m
    return None, None
