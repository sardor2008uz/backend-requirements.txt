# PSA Academy — Telegram Mini App

Talabalar uchun to'liq akademiya ilovasi: darslar, testlar, XP/reyting tizimi, profil.
Ilova Telegram ichida ochiladi — alohida yuklab olish shart emas.

## Loyiha tuzilishi

```
academy/
├── backend/
│   ├── main.py           ← Server (API + bot)
│   ├── database.py       ← Ma'lumotlar bazasi
│   ├── content.py        ← DARSLAR VA TESTLAR — shu faylni tahrirlab kontent qo'shasiz
│   └── requirements.txt
└── frontend/
    └── index.html        ← Talaba ko'radigan ilova
```

---

## 1-QADAM: Telegram bot yaratish

1. Telegram'da **@BotFather** ga yozing
2. `/newbot` buyrug'ini yuboring
3. Bot uchun nom bering (masalan: `PSA Academy`)
4. Username bering — `bot` bilan tugashi shart (masalan: `psa_academy_bot`)
5. BotFather sizga **token** beradi — bu maxfiy kalit, hech kimga bermang. Masalan:
   ```
   7123456789:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   ```
6. Shu tokenni saqlab qo'ying — pastda kerak bo'ladi.

---

## 2-QADAM: Kodni bepul hostingga joylash (Render.com)

Kod ishlashi uchun uni internetga chiqarish kerak. **Render.com** — bepul, oddiy va tezkor variant.

1. [render.com](https://render.com) da ro'yxatdan o'ting (GitHub akkaunt bilan kirish qulay)
2. Bu loyihani GitHub'ga yuklang (yangi repository yarating, fayllarni yuklang)
3. Render'da **"New +" → "Web Service"** tugmasini bosing
4. GitHub repository'ni tanlang
5. Sozlamalarni kiriting:
   - **Root Directory:** `academy/backend`
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn main:app --host 0.0.0.0 --port $PORT`
6. **Environment Variables** bo'limida qo'shing:
   | Nomi | Qiymati |
   |---|---|
   | `BOT_TOKEN` | BotFather'dan olgan tokeningiz |
   | `WEBAPP_URL` | Deploy tugagach beriladigan manzil (masalan `https://psa-academy.onrender.com`) — birinchi marta bo'sh qoldirib, deploydan keyin qo'shib qayta saqlaysiz |
7. **"Create Web Service"** tugmasini bosing — 2-3 daqiqada tayyor bo'ladi
8. Render sizga domen beradi, masalan: `https://psa-academy.onrender.com` — shu manzilni nusxalab, `WEBAPP_URL` o'zgaruvchisiga qo'shib qayta saqlang (service qayta ishga tushadi)

> Eslatma: Render bepul tarifda bir necha daqiqa harakatsizlikdan so'ng "uxlab qoladi" va birinchi so'rovda 20-30 soniya sekinlashishi mumkin. Agar akademiya faol bo'lsa, keyinchalik pullik tarifga ($7/oy) o'tish tavsiya etiladi — bu allaqachon tayyor kodni o'zgartirishni talab qilmaydi.

---

## 3-QADAM: BotFather'da Mini App tugmasini sozlash

1. @BotFather'ga qayting
2. `/mybots` → botingizni tanlang → **Bot Settings** → **Menu Button**
3. **Configure Menu Button** ni tanlang
4. Render'dan olgan manzilingizni kiriting: `https://psa-academy.onrender.com`
5. Tugma nomini kiriting, masalan: `Akademiya`

Endi botingizga kirgan har bir talaba pastda **"Akademiya"** tugmasini ko'radi — bosganda ilova ochiladi.

---

## 4-QADAM: Kontent qo'shish / tahrirlash

`backend/content.py` faylini oching. Har bir modul va dars aniq formatda yozilgan — shu formatga qarab:

- **Yangi dars qo'shish:** kerakli modulning `"lessons"` ro'yxatiga yangi qator qo'shing:
  ```python
  {
      "id": "sotuv_4",              # noyob bo'lishi shart
      "title": "4-dars: Sarlavha",
      "xp": 10,
      "content": "Dars matni bu yerda...",
  },
  ```
- **Yangi modul qo'shish:** `MODULES` ro'yxatiga yangi modul-dict qo'shing (yuqoridagilarga o'xshab)
- O'zgartirishdan so'ng, GitHub'ga yangi versiyani yuklasangiz, Render avtomatik qayta deploy qiladi.

---

## Ilova imkoniyatlari (v1)

- ✅ 6 ta modul: Sotuv, Tizimlashtirish, Boshqaruv, Moliya, Mijoz/CRM, Amaliy keys'lar
- ✅ Har bir modulda darslar + progress belgilash
- ✅ Har bir modul oxirida test (barcha darslar tugagach ochiladi)
- ✅ XP va daraja (level) tizimi
- ✅ Reyting jadvali (barcha a'zolar orasida)
- ✅ Profil sahifasi (statistika)
- ✅ Telegram orqali xavfsiz autentifikatsiya (initData HMAC tekshiruvi bilan)

## Keyingi bosqichda qo'shish mumkin bo'lgan imkoniyatlar

- Sertifikat generatsiyasi (barcha modullarni tugatganlarga)
- Push-xabarlar (yangi dars chiqqanda botdan xabar)
- Admin panel (kontentni saytdan turib qo'shish, content.py'ni qo'lda tahrirlamasdan)
- Video/audio darslar
